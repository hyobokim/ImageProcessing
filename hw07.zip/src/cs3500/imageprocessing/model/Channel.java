package cs3500.imageprocessing.model;

/**
 * Represents the channels of color in a pixel.
 */
public enum Channel {
  RED, GREEN, BLUE
}
