import static org.junit.Assert.assertEquals;

import cs3500.imageprocessing.controller.SwingController;
import cs3500.imageprocessing.model.LayeredImageModel;
import cs3500.imageprocessing.model.LayeredImageModelImpl;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.junit.Test;

public class ActionListenerTest {

  @Test
  public void testActionListener() {

    LayeredImageModel model = new LayeredImageModelImpl();
    SwingController control = new SwingController(model);

    ActionEvent test = new ActionEvent(control, 001, "checkerboard");
    assertEquals(model.numLayers(), 0);

    control.actionPerformed(test);

    assertEquals(model.numLayers(), 1);

  }
}
